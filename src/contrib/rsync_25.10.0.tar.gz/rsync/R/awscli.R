awscli <- function(src, dest, includes = NULL, excludes = NULL, args = "", profile = NULL, endpoint_url = NULL, intern = FALSE) {
  constructArg <- function(x, s) {
    if (is.null(x)) {
      return(x)
    }
    paste(paste0(s, " \"", x, "\""), collapse = " ")
  }

  includes <- constructArg(includes, "--include")
  excludes <- constructArg(excludes, "--exclude")
  profile <- if (is.null(profile)) "" else paste("--profile", profile)
  endpoint <- if (is.null(endpoint_url)) "" else paste("--endpoint-url", endpoint_url)
  dest <- paste("\"", dest, "\"", sep = "")
  src <- if (!is.null(src)) paste("\"", src, "\"", sep = "") else NULL

  command <- paste(
    "aws s3",
    args,
    excludes,
    includes,
    profile,
    endpoint,
    src,
    dest
  )
  # cat(command, "\n")

  status <- system(command, intern = intern, wait = TRUE, ignore.stdout = FALSE, ignore.stderr = FALSE)
  checkSystemResult(status)
}
