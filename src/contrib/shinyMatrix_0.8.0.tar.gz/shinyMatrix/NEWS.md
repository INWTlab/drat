# ShinyMatrix 0.8.0

* Add parameter to format cells

# ShinyMatrix 0.7.0

## Updates

* Fix: Bug when using extend feature for rows in the matrix #21
* Feature: Change or disable click behavior #26
* Improve tabbing and extension functionality
* Online Documentation (pkgdown) & R-CMD Check

