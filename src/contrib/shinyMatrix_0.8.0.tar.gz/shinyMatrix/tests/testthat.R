library(testthat)
library(shinyMatrix)

test_check("shinyMatrix")
