select 1 as x;
-- inline comment
select 1 as x;
# inline comment
select 1 as x;
/* comment spanning
multiple lines */
select 1 as x;
