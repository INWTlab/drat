library(testthat)
library(dbtools)

test_check("dbtools")
