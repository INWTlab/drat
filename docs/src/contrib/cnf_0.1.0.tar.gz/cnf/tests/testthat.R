library(testthat)
library(cnf)

test_check("cnf")
